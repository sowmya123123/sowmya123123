const { Router } = require('express');
const express=require('express');
const Route =express.Router();
const connection=require('../config/db');

 const apiauth=async (req, res, next)=>{
    const headerval=req.headers.authorization.split(' ')[1];
    // console.log(headerval);
    const token={'data':headerval}
  // console.log(token);
   if(token.data===undefined || token.data===''){
     return res.status(401).json({
      msg:"Enter Valid Token",
      data:"",
      status:0,
      error:1
     })
   }else{
    connection.query("SELECT token FROM user WHERE user.token= ?", [headerval], function (err, result) {
      var obj = Object.assign({}, ...result);
      //  console.log(obj.token);
       const validtoken={'data':obj.token}
      //  console.log(validtoken)
      if(validtoken.data ==='' || validtoken.data=== undefined){
          return res.status(401).json({
                     msg:"invalid token",
                     data:"",
                     status:0,
                     error:1
                 })
        } else{
         next()
            
       }
       });
  }
 }
  module.exports=apiauth;