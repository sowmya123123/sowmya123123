const AWS = require('aws-sdk');
const multer = require('multer');
const upload = multer({ dest: 'public/'});
const fileSystem = require('fs');
require('dotenv').config();


const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_SECRET_ID,
  secretAccessKey: process.env.AWS_SECRET_KEY
});



async function uploadFile(fileName, fileKey) {
  return new Promise(async function(resolve, reject) {
  const params = {
  Bucket: 'bamchik-video', // pass your bucket name
  Key: fileKey,
  ACL: 'public-read',
  Body: fileSystem.createReadStream(fileName.path),
  ContentType: fileName.type
  };
// console.log(params);
  await s3.upload(params, function(s3Err, data) {
    if (s3Err){
    reject(s3Err);
    }
    // console.log(`File uploaded successfully at ${data.Location}`);
    resolve(data.Location);
    });
    });
    }




    module.exports = uploadFile