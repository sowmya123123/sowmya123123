const fs=require('fs');
const aws=require('aws-sdk');
 multer = require('multer'),
 multerS3 = require('multer-s3');
 require('dotenv').config();
 const datetime=require('node-datetime');
 const dt=datetime.create();
 const path = require('path');



aws.config.update({
  secretAccessKey: process.env.AWS_SECRET_KEY ,
  accessKeyId: process.env.AWS_SECRET_ID,
  region: 'ap-south-1'
});
s3 = new aws.S3();
 exports.upload=multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: "bamchik-video",
    metadata: function(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function(req, file, cb) {
      cb(null,'profile/' +Date.now().toString() + path.extname(file.originalname));
  
    },
    throwMimeTypeConflictErrorIf: (contentType, mimeType,_file) => ![mimeType, 'application/octet-stream'].includes(contentType)
  })
});


