const jwt=require('jsonwebtoken');
const adminModel=require('../models/admin');

const requireAuth=(req,res,next)=>{
    const token=req.cookies.jwt;

    if(token){
        jwt.verify(token,'secret_key',(err,decodedToken)=>{
            if(err){
                console.log(err.message);
                res.rediret('/admin/login');

            }else{
                //console.log();
                next();
    
            }
        })
    
    }else{
        res.redirect('/admin/login');
    }
}
module.exports={requireAuth};