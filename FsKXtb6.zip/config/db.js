var mysql = require('mysql');
require('dotenv').config();
var connection = mysql.createPool({
    connectionLimit : 1000,
    host     : process.env.RDS_HOSTNAME,
    user     : process.env.RDS_USERNAME,
    password : process.env.RDS_PASSWORD,
    port     : process.env.RDS_PORT,
    database : process.env.RDS_DATABASE_NAME
});

// var connection = mysql.createConnection({
//   host     : process.env.RDS_HOSTNAME,
//   user     : 'root',
//   password : process.env.PASSWORD,    
//   port     : process.env.RDS_PORT,
//   database : process.env.DB_NAME
// });
connection.getConnection(function(err, connection) {
  if (err) throw err; // not connected!

  // Use the connection
  connection.query('SELECT name FROM user WHERE user.id=?',[1], function (error, results, fields) {
    console.log("connected");
  });
});


module.exports=connection;