const connection=require('../config/db');
const jwt = require("jsonwebtoken");
var dateTime = require('node-datetime');
var dt = dateTime.create();
const { RegulationContext } = require('twilio/lib/rest/numbers/v2/regulatoryCompliance/regulation');
const { response } = require('express');
const accountSid = 'AC0396784ca80bd0be5a4d601e7ede222c';
const authToken = 'e83312a5366fd47c421d5d0760538ab1';
const client = require('twilio')(accountSid, authToken);

exports.login=async(req,res)=>{
    const phone = req.body.contact;
    const accesstoken = jwt.sign({ sub: phone }, process.env.JWT_ACCESS_SECRET, { expiresIn: process.env.JWT_ACCESS_TIME });
     connection.query("SELECT * FROM user WHERE user.contact=?",[phone],function(err,result){
        const obj = Object.assign({}, ...result);
    if(obj.contact==phone){
    connection.query("UPDATE user SET token =? WHERE user.contact=?", [accesstoken, phone], function (err, result) {

        return res.json({
            "status": "200",
            "message": "Successfully login..",
            "userId": obj.id,
            "name": obj.name,
            "username": obj.username,
            "profileUrl": obj.profile_url,
            "token": accesstoken,
            "referralCode": obj.refer_code,
            "languagePrefernce": obj.lang_preferences
        })
    })
    }else{
        return res.json({
            "status": "202",
            "message": "Login Unsuccessfull..",
        })
    }

    });

        }


 exports.signUp = async (req, res) => {
            const phone = req.body.contact;
            const accesstoken = jwt.sign({ sub: phone }, process.env.JWT_ACCESS_SECRET, { expiresIn: process.env.JWT_ACCESS_TIME });

            let sql = 'INSERT INTO user SET ?';
            let post = {
                name: req.body.name,
                contact: phone,
                token: accesstoken,
                password: req.body.password,
                refer_code: req.body.referralCode,
                username: req.body.username,
                cover_url:"",
                created_on:"",
                date_of_birth:req.body.dateOfBirth,
                device_id:req.body.deviceId,
                earnings:0,
                is_user_verified:0,
                lang_preferences:1,
                no_of_followers:0,
                no_of_followings:0,
                no_of_likes:0,
                no_of_posts:0,
                profile_url:"",
                updated_on:""
                
            };
            // console.log(post);
            connection.query(sql, post, function (err, result) {
                connection.query("SELECT * FROM user WHERE user.contact=?",[phone],function(err,result){
                    const obj = Object.assign({}, ...result);
                if(user.contact==phone){   
                return res.json({
                    "status": "200",
                    "message": "Successfully login..",
                    "userId": obj.id,
                    "name": obj.name,
                    "username": obj.username,
                    "profileUrl": obj.profile_url,
                    "token": obj.token,
                    "referralCode": obj.refer_code,
                    "languagePrefernce": obj.lang_preferences
                });
            }else{
                return res.json({
                    "status": "202",
                    "message": "Login Unsuccessfull..",
                }) 
            }
        
            });
         })
        }
        exports.checkusername=async(req,res)=>{
            const username=req.body.username;
            connection.query("SELECT username FROM user WHERE user.username= ?", [ username ], function (err, result) {
        
                 var obj = Object.assign({}, ...result)
                if(obj.username == username){
                    return res.json({
                        msg: "username already registered..",
                        status: "400"
                    });
                }else{
                    return res.json({
                        msg:"Username available..",
                        status:"200",
                    })
                }
                });
        },
        exports.verifyReferCode=async(req,res)=>{
            const refer_code=req.body.refer_code;
            connection.query("SELECT refer_code FROM user WHERE user.refer_code= ?", [refer_code ], function (err, result) {
                var obj = Object.assign({}, ...result)
                 
                if(obj.refer_code == refer_code){
                    return res.json({
                        msg: "this refer code belong to someone",
                        status: "400",
                    });
                }else{
                    return res.json({
                        msg:"this refer code does not belong to anyone",
                        status:"200"
                    })
                }
                });
        },
        exports.getaudiocategory = async (req, res) => {
            connection.query("SELECT category_id AS categoryId,category_name AS categoryName,icon_url AS iconUrl FROM audio_category", function (err, result) {
                

                return res.json({
                    "status": "200",
                    "message": "Category details..",
                    "lastPageIndex": 0,
                    "audioCategoryResponse":result
                });
            });
        },
        exports.getCategorydetails = async (req, res) => {
            const id = req.body.category_id;
            connection.query("SELECT * FROM audio_category WHERE audio_category.category_id= ?", [id], function (err, result) {
               

                return res.json({
                    msg: "get all audio details ",
                    data: result,
                    status: 1,
                    error: 0
                });
            });
        },
        exports.searchCategory = async (req, res) => {
            const data = req.body.search;
            connection.query('SELECT * FROM audio_category where audio_category.category_name like ?', ['%' + data + '%'], function (err, result) {
               

                return res.json({
                    msg: "get all audio category ",
                    data: result,
                    status: 1,
                    error: 0
                });
            });

        },
        exports.getAllaudioromcategory = async (req, res) => {
            const id = req.body.categoryId;
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT DISTINCT track_name AS trackName ,audio_id AS audioId,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio WHERE audio.category_id= ?", [id], function (err, result) {
            connection.query("SELECT DISTINCT track_name AS trackName ,audio_id AS audioId,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio WHERE audio.category_id= ? LIMIT ? OFFSET ?", [id,limit,skip], function (err, response) {
                if(result===undefined || response===undefined){
                    return res.json({
                        "status": "200",
                        "message": "Audio List",
                        "lastPageIndex":Number(page) ,
                        "audioResponses": []
                })
                }else{
                const count=result.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Audio List",
                        "lastPageIndex":page ,
                        "audioResponses": []
                })
                }else{
                const n=response.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(response[i]).forEach(function (field) {
                    if(response[i][field] == null){
                        response[i].saved=false;
                    }
                  
                    })                   
            };
            // const response = result.map(v => ({...v, saved: v.false }));

                return res.json({
                    "status": "200",
                    "message": "Audio List",
                    "lastPageIndex":Number(page),
                    "audioResponses":response
                });
            }
        }
            });
        });
        },
        exports.getAllAudio = async (req, res) => {
            connection.query("SELECT * FROM audio", function (err, result) {
               

                return res.json({
                    msg: "get all audio category ",
                    data: result,
                    status: 1,
                    error: 0
                });
            });
        },
        exports.findAudio = async (req, res) => {
            const data = req.body.trackName;
            const page=req.body.lastPageCount;
            var limit = 10;
            var skip = page * limit - page;
            connection.query('SELECT track_name AS trackName ,audio_id AS audioId,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio where audio.track_name like ? OR audio.track_detail like ? LIMIT ? OFFSET ?', ['%' + data + '%','%' + data + '%',limit,skip], function (err, result) {
                connection.query("SELECT track_name AS trackName ,audio_id AS audioId,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio where audio.track_detail like ? OR audio.track_name like ?",['%' + data + '%','%' + data + '%'],function(err,datatwo){
                if(result===undefined || datatwo===undefined){
                    return res.json({
                        "status": "200",
                        "message": "Searched Audio is",
                        "lastPageIndex":page ,
                        "audioResponse": []
                })
                }else{
                const count=datatwo.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Searched Audio is",
                        "lastPageIndex":page ,
                        "audioResponse": []
                })
                }else{
            
                const n=result.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(result[i]).forEach(function (field) {
                    if(result[i][field] == null){
                        result[i][field] = 0;
                        result[i].saved=false;
                    }
                  
                    })                   
            };
                return res.json({
                    "status": "200",
                    "message": "Searched Audio is",
                    "lastPageIndex":Number(page) ,
                    "audioResponses": result
            })
        }
    }
        })
    })
        
 
        },
        exports.getAudiodetails = async (req, res) => {
            const id = req.body.audioId;
                const headerval=req.headers.authorization.split(' ')[1];
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,response){
                var user = Object.assign({}, ...response);
            //   console.log(user.id)
                      
            connection.query("SELECT * FROM saved_audio WHERE saved_audio.audio_id=? AND saved_audio.user_id=?",[id,user.id],function(err,data){
             var obj = Object.assign({}, ...data);
            //  console.log(obj.user_id)
             if(obj.user_id===user.id && user.id!==undefined){
            
            connection.query("SELECT audio_id AS audioId,track_name AS trackName,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio WHERE audio.audio_id= ?", [id], function (err, result) {
                const n=result.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(result[i]).forEach(function (field) {
                    if(result[i][field] == null){
                        result[i][field] = 0;
                        result[i].saved= true
                    }
                  
                    })                   
            };
           
            var response = Object.assign({}, ...result);
                
                return res.json({
                "status": "200",
                "message": "audio detail",
                "audio": response
                });
            })
            
        }else{
            const saved=[{'saved':'false'}];
            connection.query("SELECT audio_id AS audioId,track_name AS trackName,track_detail AS trackDetail,track_url AS trackUrl,thumbnail_url AS thumbnailUrl,no_of_user AS noOfUser FROM audio WHERE audio.audio_id= ?", [id], function (err, result) {
                const n=result.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(result[i]).forEach(function (field) {
                    if(result[i][field] == null){
                        result[i][field] = 0;
                        result[i].saved= false
                    }
                  
                    })                   
            };
            var response = Object.assign({}, ...result);
           
              
            return res.json({
                "status": "200",
                "message": "audio detail",
                "audio": response
            });
        });
        }
            });
        })
        },
        exports.getVideolistforAudio=async(req,res)=>{
            const audioid=req.body.audioId;
            const headerval=req.headers.authorization.split(' ')[1];
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result);
              const id=obj.id
           
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.audio_id=? LIMIT ? OFFSET ?",[id,id,id,audioid,limit,skip],function(err,result){
                const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                         result[i].verified=false
                     }
                   
                     })                   
             };
                return res.json({
                    "status": "200",
                    "message": "List of videos..",
                    "lastPageIndex": page,
                    "videoResponse": result
                });
            })
        })
        },
        exports.myVideo=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result);
                 const id=obj.id;
        //    console.log(obj.id)
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.user_id=? LIMIT ? OFFSET ? ",[id,id,id,id,limit,skip],function(err,result){
                const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                         result[i].verified=false
                     }
                   
                     })                   
             };
                return res.json({
                    "status": "200",
                    "message": "successfully..",
                    "lastPageIndex": page,
                    "videoResponse": result
                });
            })
        })
        },
        exports.publicvideo=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
            const page=req.body.lastPageIndex;
            const id=req.body.userId;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result);
                 
        //    console.log(obj.id)
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.user_id=? LIMIT ? OFFSET ? ",[obj.id,obj.id,obj.id,id,limit,skip],function(err,result){
                const n=result.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(result[i]).forEach(function (field) {
                    if(result[i][field] == null){
                        result[i][field] = 0;
                        result[i].verified=false
                    }
                  
                    })                   
            };
                return res.json({
                    "status": "200",
                    "message": "Successfully..",
                    "lastPageIndex": page,
                    "videoResponse": result
                });
            })
        })
        },
       
        exports.getsavedaudio=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,response){
                var obj = Object.assign({}, ...response);
                const userid=obj.id;
                
            connection.query("SELECT DISTINCT audio.track_name AS trackName ,audio.audio_id AS audioId,audio.track_detail AS trackDetail,audio.track_url AS trackUrl,audio.thumbnail_url AS thumbnailUrl,audio.no_of_user AS noOfUser FROM audio INNER JOIN saved_audio ON audio.audio_id=saved_audio.audio_id WHERE saved_audio.user_id=? LIMIT ? OFFSET ?",[userid,limit,skip],function(err,result){
            connection.query("SELECT DISTINCT audio.track_name AS trackName ,audio.audio_id AS audioId,audio.track_detail AS trackDetail,audio.track_url AS trackUrl,audio.thumbnail_url AS thumbnailUrl,audio.no_of_user AS noOfUser FROM audio INNER JOIN saved_audio ON audio.audio_id=saved_audio.audio_id WHERE saved_audio.user_id=?",[userid],function(err,response){
              if('undefined'===result || 'undefined'===response){
                return res.json({
                    "status":"200",
                    "message": "Audio List",
                    "lastPageIndex":Number(page),
                    "audioResponses": []
                });
            }else{
                const n=result.length;
                const count=response.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status":"200",
                        "message": "Audio List",
                        "lastPageIndex":Number(page),
                        "audioResponses":[]
                    });
                }else{
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i].saved=Boolean(true)
                     }
                   
                     })                   
             };
             return res.json({
                "status":"200",
                "message": "Audio List",
                "lastPageIndex":Number(page),
                "audioResponses": result
            });
        }
    } 
    })
})
        })
        },
        exports.saveaudio=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,response){
                var obj = Object.assign({}, ...response);
              
          if(obj.id>0==true){
            let sql = 'INSERT INTO saved_audio SET ?';
            let post = {
                user_id: obj.id,
                audio_id: req.body.audioId
            }
            connection.query(sql,post,function(err,result){
                return res.json({
                     "status": "200",
                     "message": "Audio has been saved!"
                    
                });
            })
        }else{
            return res.json({
                "status": "400",
                "message": "Audio not saved!"
               
           });
        }
        })
        },
        exports.getCommentDetails = async (req, res) => {
            const id = req.body.id;
            connection.query("SELECT * FROM post_comment WHERE post_comment.comment_id=?", [id], function (err, result) {
                var obj = Object.assign({}, ...result);
               

                return res.json({
                    msg: "get all comment details ",
                    data: obj,
                    status: 1,
                    error: 0
                });
            });
        },
        exports.getAllComment=async(req,res)=>{
            const referenceId=req.body.referenceId;
            const commentType=req.body.commentType;
            const page=req.body.lastPageIndex;
            // console.log(referenceId);
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT  user.username AS username , user.profile_url AS profileUrl, post_comment.comment AS comment, post_comment.commented_on AS commentedOn,post_comment.comment_id AS commentId,post_comment.user_id AS userId FROM user INNER JOIN post_comment ON user.id=post_comment.user_id WHERE reference_id=? LIMIT ? OFFSET ?",[referenceId,limit,skip],function(err,result){
            connection.query("SELECT  user.username AS username , user.profile_url AS profileUrl, post_comment.comment AS comment, post_comment.commented_on AS commentedOn,post_comment.comment_id AS commentId,post_comment.user_id AS userId FROM user INNER JOIN post_comment ON user.id=post_comment.user_id WHERE reference_id=?",[referenceId],function(err,response){
              if('undefined'=== result || 'undefined'=== response){
                return res.json({
                    "status": "200",
                    "message": "Comments List..",
                    "lastPageIndex": 0,
                    "commentResponse": []
                })
            }else{
                const count=response.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Comments List..",
                        "lastPageIndex": 0,
                        "commentResponse": []
                    })
                }else{
                    const n=result.length;
                    for (var i = 0; i < n; i++) {
                        Object.keys(result[i]).forEach(function (field) {
                        if(result[i].status !== null){
                          result[i].commentedOn= String(result[i].commentedOn.toLocaleString().split('/').join('-').slice(0,9) +" "+result[i].commentedOn.toLocaleString().slice(10,19)); 
                        //  result[i].commentedOn=result[i].commentedOn.toString().substr(0,24);
                        }                    
                        })                   
                };
                    return res.json({
                        "status": "200",
                        "message": "Comments List..",
                        "lastPageIndex": 0,
                        "commentResponse": result
                    })
                }
            }
            })
        })
        },

        exports.postcomment = async (req, res) => {
                const headerval=req.headers.authorization.split(' ')[1];
            
            const dateTime= dt.format('Y-m-d H:M:S').slice(0,19).replace('T',':')
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result);
            const userId=obj.id;
            
            let sql = 'INSERT INTO post_comment SET ?';
            let post = {
                comment: req.body.comment,
                comment_type: req.body.commentType,
                commented_on: dateTime,
                reference_id: req.body.referenceId,
                user_id: userId
            };
            // console.log(post);
            connection.query(sql, post, function (err, result) {
                // console.log(result);
            connection.query("SELECT * FROM video WHERE video.video_id=?",[req.body.referenceId],function(err,response){
                var obj = Object.assign({}, ...response);
                
                 var count=+1+obj.no_of_comment;
                 // console.log(follower);
                 var sql = 'UPDATE video SET no_of_comment = ? WHERE video.video_id=?';
                 var value = [count,req.body.referenceId  ];
                 connection.query(sql,value, function(err, result){                   
                   
                return res.json({
                    "status": 200,
                    "message": "comment added successfully",
                    
                });
            
        })
        });
        });

        })
        },

        exports.deleteComment = async (req, res) => {
         
            const id=req.query.comment_id;
        // console.log(id);
            connection.query("DELETE FROM post_comment WHERE post_comment.comment_id = ?", [id], function (err, result) {
                if (err)
                    throw err;

                return res.json({
                    "status":200,
                    "message": "Comment Delete Successfully ",
                
                });
            });
        },
        exports.updateComment = async (req, res) => {
            var query = 'UPDATE post_comment SET profile_name = ?, phone =?, .. WHERE id=?';
            var value = [req.body, req.body];
            connection.query(query, value, function (err, result) {
                if (err)
                    throw err;

                return res.json({
                   "status":200,
                   "message":"Comment Updated Successfully"
                });
            });
        },
        exports.getuserDetails=async(req,res)=>{
                const headerval=req.headers.authorization.split(' ')[1];
            const userid=req.body.userId;
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,response){
                var user = Object.assign({}, ...response);
                
            connection.query("SELECT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,user.cover_url AS coverUrl,user.no_of_posts AS posts,user.no_of_followers AS followers,user.no_of_followings AS following,user.earnings AS earnings,user.refer_code AS referralCode,CASE WHEN user.is_user_verified =1 THEN true ELSE false END AS verified,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN 0 ELSE 1 END  AS followStatus FROM user LEFT JOIN relation ON relation.following_id=? AND relation.follower_id=? WHERE user.id=?",[userid,user.id,userid],function(err,result){
            connection.query("SELECT weekly_contest_id AS weeklyContestId,category_name AS categoryName,thumbnail_url AS thumbnailUrl FROM weekly_contest",function(err,weeklycontest){
 
                if(result===undefined || weeklycontest===undefined){
                return res.json({
                    "status": "200",
                    "message": "Successfully..",
                    "userResponse": "",
                    "weeklyContestResponse":""
                                    
                }) 
             }else{
                 const data=Object.assign({}, ...result);
            if(data.verified==0){    
            var response = {
                "userId": data.userId.toString(),
                "name": data.name,
                "profileUrl": data.profileUrl,
                "coverUrl": data.coverUrl,
                "posts": data.posts,
                "followers":data.followers.toString(),
                "following":data.following.toString(),
                "earnings": data.earnings.toString(),
                "referralCode":data.referralCode,
                "verified": false,
                "followStatus": data.followStatus
            }

                return res.json({
                     "status": "200",
                     "message": "Successfully..",
                     "userResponse": response,
                     "weeklyContestResponse":weeklycontest
                })
            }else{
                var response = {
                    "userId": data.userId.toString(),
                    "name": data.name,
                    "profileUrl": data.profileUrl,
                    "coverUrl": data.coverUrl,
                    "posts": data.posts,
                    "followers":data.followers.toString(),
                    "following":data.following.toString(),
                    "earnings": data.earnings.toString(),
                    "referralCode":data.referralCode,
                    "verified": true,
                    "followStatus": data.followStatus
                }
    
                    return res.json({
                         "status": "200",
                         "message": "Successfully..",
                         "userResponse": response,
                         "weeklyContestResponse":weeklycontest
                    })
            }
            }                  
    })

      })
       })
        },
     
        exports.getmineDetails=async(req,res)=>{
                const headerval=req.headers.authorization.split(' ')[1];

            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                connection.query("SELECT weekly_contest_id AS weeklyContestId,category_name AS categoryName,thumbnail_url AS thumbnailUrl FROM weekly_contest",function(err,data){
            
                var obj = Object.assign({}, ...result);
                const id=obj.id.toString();
                const followers=obj.no_of_followers.toString();
                const following=obj.no_of_followings.toString();
                const earnings=obj.earnings.toString();
                if(obj.is_user_verified===01){
                const response={
                   "userId": id,
                   "name": obj.name,
                   "profileUrl":obj.profile_url,
                   "coverUrl": obj.cover_url,
                   "posts": obj.no_of_posts,
                   "followers": followers,
                   "following": following,
                   "earnings": earnings,
                   "referralCode": obj.refer_code,
                   "followStatus": 0,
                   "verified": true
                }
            
                return res.json({
                    "status": "200",
                     "message": "Successfully..",
                     "userResponse": response,
                     "weeklyContestResponse":data
                     
                 })
                }else{
                    const response={
                        "userId": id,
                        "name": obj.name,
                        "profileUrl":obj.profile_url,
                        "coverUrl": obj.cover_url,
                        "posts": obj.no_of_posts,
                        "followers": followers,
                        "following": following,
                        "earnings": earnings,
                        "referralCode": obj.refer_code,
                        "followStatus": 0,
                        "verified": true
                     }
                 
                     return res.json({
                         "status": "200",
                          "message": "Successfully..",
                          "userResponse": response,
                          "weeklyContestResponse":data
                          
                      }) 
                }
            })
        })
        },
        exports.getfollower=async(req,res)=>{
            const id=req.body.userId;
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            
            connection.query("SELECT user.id AS userId ,user.username AS username, user.name AS name, user.profile_url AS profileUrl,user.no_of_followers AS followers FROM user INNER JOIN relation ON user.id=relation.follower_id WHERE following_id=? LIMIT ? OFFSET ?",[id,limit,skip],function(err,result){
            connection.query("SELECT user.id AS userId ,user.username AS username, user.name AS name, user.profile_url AS profileUrl,user.no_of_followers AS followers FROM user INNER JOIN relation ON user.id=relation.follower_id WHERE following_id=? ",[id],function(err,response){
                const count =response.length;
                const date =result.length;
                var totalPages = Math.ceil(count / limit);
                if(undefined !== response && response.length||undefined!==result && result.length){
                if(page>totalPages==true){
                    return res.json({
                        "status":"200",
                        "message":"Follower list ..",
                        "totalFollowers":count,
                        "followResponse":[],
                        "lastPageIndex":Number(page)
                     })
                }else{
                   
                     for (var i = 0; i < date; i++) {
                        Object.keys(result[i]).forEach(function (field) {
                        if(result[i][field] !== null){
                            result[i].userId= result[i].userId.toString();
                            result[i].followers=result[i].followers.toString();
                        }
                      
                        })                   
                };
                    return res.json({
                        "status":"200",
                        "message":"Follower list ..",
                        "totalFollowers":count,
                        "followResponse":result,
                        "lastPageIndex":Number(page)
                     })
                }

            }else{
                return res.json({
                    "status":"200",
                    "message":"Follower list ..",
                    "totalFollowers":count,
                    "followResponse":[],
                    "lastPageIndex":Number(page)
                 })
            }

            })
            })
        },
        exports.getfollowing=async(req,res)=>{
            const id=req.body.userId;
            const page=req.body.lastPageIndex;
            var limit = 10;
            var skip = page * limit - page;
            connection.query("SELECT user.id AS userId ,user.username AS username, user.name AS name, user.profile_url AS profileUrl ,user.no_of_followers AS followers FROM user INNER JOIN relation ON user.id=relation.following_id WHERE follower_id=? LIMIT ? OFFSET ?",[id,limit,skip],function(err,result){
                connection.query("SELECT user.id AS userId ,user.username AS username, user.name AS name, user.profile_url AS profileUrl ,user.no_of_followers AS followers FROM user INNER JOIN relation ON user.id=relation.following_id WHERE follower_id=?",[id],function(err,response){
               const count=response.length;
                const date=result.length;
                var totalPages = Math.ceil(count / limit);
                if(undefined !== response && response.length||undefined!==result && result.length){
                
                if(page>totalPages==true){
                    return res.json({
                        "status":"200",
                        "message":"Following List ..",
                        "totalFollowing":count,
                        "followingResponse":[],
                        "lastPageIndex":Number(page)
                     })
                }else{
                   
                     for (var i = 0; i < date; i++) {
                        Object.keys(result[i]).forEach(function (field) {
                        if(result[i][field] !== null){
                            result[i].userId= result[i].userId.toString();
                            result[i].followers=result[i].followers.toString();
                        }
                      
                        })                   
                };
                    return res.json({
                        "status":"200",
                        "message":"Following List ..",
                        "totalFollowing":count,
                        "followingResponse":result,
                        "lastPageIndex":Number(page)
                     })
                }
            }else{
                 return res.json({
                        "status":"200",
                        "message":"Following List ..",
                        "totalFollowing":count,
                        "followingResponse":[],
                        "lastPageIndex":Number(page)
                     })
            }
            })
            })
        
        },
        exports.getvideolist=async(req,res)=>{
            const id=req.body.userId;

            connection.query("Select e.*, z.zoneName, s.sectorName, b.beatName From user u INNER JOIN video v ON u.id = v.user_id INNER JOIN sector s ON e.sectorID = s.id INNER JOIN Beat b ON e.beatID = b.id;",[id],function(err,result){
                return res.json({
                    msg: "Video List",
                    data: result,
                    status: 1,
                    error: 0 
                })
            })
        },
        exports.getparticularvideo=async(req,res)=>{
            const vid=req.body.videoId;
            const headerval=req.headers.authorization.split(' ')[1];
            // console.log(headerval);
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
            //    console.log(result)
                if(result===undefined){
                    return res.json({
                        "status": "200",
                        "message": "Success....",
                        "videoResponse": []
                    })
             }else{
           
            var obj = Object.assign({}, ...result);
                   const id=obj.id;
           
            connection.query("SELECT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.video_id=? LIMIT 1",[id,id,id,vid],function(err,response){
               if(response===undefined){
                return res.json({
                    "status": "200",
                    "message": "Success..",
                    "videoResponse": []
                })
               }else{
                   const n=response.length;
                for (var i = 0; i < n; i++) {
                    Object.keys(response[i]).forEach(function (field) {
                    if(response[i][field] == null){
                        response[i][field] = 0;
                      if(response[i].verified==0){
                        response[i].verified=false;
                      }else{
                        response[i].verified=true;

                      }
                    }
                  
                    })                   
            };
                return res.json({
                    "status": "200",
                    "message": "Success..",
                    "videoResponse": response
                })
            }
            })
        }
        })
        },
        exports.reportVideo=async(req,res)=>{
                const headerval=req.headers.authorization.split(' ')[1];
           
         
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
             var obj = Object.assign({}, ...result);
             let sql = 'INSERT INTO report SET ?';
             let post = {
                user_id:obj.id,
                issue_detail: req.body.issueDetail,
                issue_type: req.body.issueType,
                reference_id:req.body.referenceId,
                reference_type:req.body.referenceType,
                user_email:req.body.userEmail
             };
          

             connection.query(sql, post, function (err, result) {
            
                    return res.json({
                        "status":200,
                        "message": "Video Reported Successfully ",
                
                    });
            });
        })
        },
        exports.searchuser = async (req, res) => {
            const data = req.body.username;
            const page=req.body.lastPageCount;
            var limit=10;
            var skip = page * limit - page;


            connection.query('SELECT id AS userId,profile_url AS profileUrl,username AS username,name AS name ,no_of_followers AS follower,no_of_followings AS following FROM user where user.name like ? LIMIT ? OFFSET ?', ['%' + data + '%',limit,skip], function (err, result) {
            connection.query('SELECT id AS userId,profile_url AS profileUrl,username AS username,name AS name ,no_of_followers AS follower,no_of_followings AS following FROM user where user.name like ? ', ['%' + data + '%'], function (err, response) {
              if(undefined===result || undefined===response){
                return res.json({
                    "status": "200",
                    "message": "Searched User List..",
                    "lastPageIndex": 0,
                    "userResponse":""
                });
                  }else{
                const count=response.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Videos List..",
                        "lastPageIndex": page,
                        "videoResponse": "",
                        })
                }else{
                const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                         
                     }
                   
                     })  
                                    
             };

                return res.json({
                    "status": "200",
                    "message": "Searched User List..",
                    "lastPageIndex": 0,
                    "userResponse":result
                });
            }
        }
            });
            });
        } ,
        exports.doFollow = async (req, res) => {
                const headerval=req.headers.authorization.split(' ')[1];

            const toFollowid=req.body.toFollowUserId;
           
            if(req.body.status==='1'){

            connection.query("SELECT * FROM user where user.token= ?", [headerval], function (err, data) {
                
             var obj = Object.assign({}, ...data);
             const userid=obj.id;
            connection.query("SELECT * FROM relation WHERE relation.following_id=? AND relation.follower_id=?",[toFollowid,userid],function(err,relation){
             var last = Object.assign({}, ...relation);
            //  console.log(obj)
             if(last.following_id==toFollowid && last.follower_id==userid){
                 return res.json({
                     "message":"User Already Followed..",
                     "status":"200"
                 })
            
        }else{
            let sql = 'INSERT INTO relation SET ?';
             let post = {
                following_id:toFollowid,
                name: obj.name,
                username: obj.username,
                follower_id:obj.id
               
             };
          //need to check
            //   console.log(post)
             connection.query(sql, post, function (err, result) {
                const followings=+1+obj.no_of_followings;
                // console.log(followings);
                var query = 'UPDATE user SET no_of_followings = ? WHERE user.id=?';
                var value = [followings, userid ];
                connection.query(query, value, function (err, result) {
                //    console.log(result)
               
                connection.query("SELECT * FROM user WHERE user.id=?",[toFollowid],function(err,response){
                var foll=Object.assign({}, ...response);
                var follower=+1+foll.no_of_followers
                // console.log(follower);
                var sql = 'UPDATE user SET no_of_followers = ? WHERE user.id=?';
                var value = [follower, toFollowid ];
                connection.query(sql,value, function(err, result){
                       if (err) throw err
                    //    console.log(result)
              

                return res.json({
                    "status":"200",
                    "message":"User Followed.."
                });
            }) 
        })    
    })
    
        })
        }
            })
        })
    }else{
            connection.query("SELECT * FROM user where user.token= ?", [headerval], function (err, response) {
            var obj=Object.assign({}, ...response);
            
            const userid=obj.id;
            const followings=-1+obj.no_of_followings;
            //  console.log(followings)
           connection.query("DELETE FROM relation WHERE relation.following_id=? AND relation.follower_id=?",[toFollowid,userid],function(err,response){
            
            var query = 'UPDATE user SET no_of_followings = ? WHERE user.id=?';
            var value = [followings, userid ];
            connection.query(query, value, function (err, result) {
            //    console.log(result)
            })
            connection.query("SELECT * FROM user WHERE user.id=?",[toFollowid],function(err,response){
            var foll=Object.assign({}, ...response);
            var follower=-1+foll.no_of_followers
        
            var sql = 'UPDATE user SET no_of_followers = ? WHERE user.id=?';
            var value = [follower, toFollowid ];
            connection.query(sql,value, function(err, result){
                   if (err) throw err
                //    console.log(result)
            })    
            })
            

            return res.json({
                "status":"200",
                "message":"User Unfollowed.."
            });
            
        })
     })
    }
    

        },
        exports.likeVideo=async(req,res)=>{
                const headerval=req.headers.authorization.split(' ')[1];
            const id=req.body.referenceId;
            const status=req.body.status;
            const likeType=req.body.likeType;
            connection.query("SELECT id,name,username FROM user WHERE user.token=?",[headerval],function(err,result){
             var obj = Object.assign({}, ...result);
            if(status==='1'){
            connection.query("SELECT * FROM post_like WHERE post_like.user_id=? AND post_like.reference_id=?",[obj.id,id],function(err,data){
             var check = Object.assign({}, ...data);
             console.log(check)
             if(check.user_id==obj.id && check.reference_id==id){
                return res.json({
                    "status":"200",
                    "message":"Video already liked",                     
                  });

             }else{

         
             let sql = 'INSERT INTO post_like SET ?';
             let post = {
                like_type: likeType,
                liked_by: obj.name,
                liked_on:dt.format('Y-m-d H:M:S'),
                reference_id:id,
                user_id:obj.id
             };
          //need to check
             console.log(post)
             connection.query(sql, post, function (err,success) {
                 if (err) throw err;
                 console.log(success)
                 connection.query("SELECT * FROM video WHERE video.video_id=?",[id],function(err,video){
                     var objtwo=Object.assign({}, ...video);
                     const totallike=+1+objtwo.no_of_like
                     console.log(totallike);
                     var sql = 'UPDATE video SET no_of_like = ? WHERE video.video_id=?';
                var value = [totallike, id ];
                 connection.query(sql,value, function(err,result){
                    return res.json({
                      "status":"200",
                      "message":"Video liked successfully",                     
                    });

                 })
                 })
              
               
            })
        }
        })
        }else{
            connection.query("SELECT * FROM video where video.video_id= ?", [id], function (err, response) {
                var objtwo=Object.assign({}, ...response);
                
                
                const counter=-1+objtwo.no_of_like;
                //  console.log(followings)
               connection.query("DELETE FROM post_like WHERE post_like.user_id=? AND post_like.reference_id=?",[obj.id,id],function(err,datadelete){
                console.log(datadelete);
                var query = 'UPDATE video SET no_of_like = ? WHERE video.video_id=?';
                var value = [counter, id ];
                connection.query(query, value, function (err, result) {
                //    console.log(result)
                })
               
    
                return res.json({
                    "status":"200",
                    "message":"Video unliked successfully"
                });
                
            })
         })
        }

        })
        },
        exports.devicedata=async(req,res)=>{
                const headerval=req.headers.authorization.split(' ')[1];
           
         
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result)
            let sql = 'INSERT INTO device_info SET ?';
             let post = {
                device_id:req.body.deviceId,
                gcm_tokken:req.body.gcmTokken,
                operating_system: req.body.operatingSystem,
                os_version:req.body.osVersion,
                user_id:obj.id,
                log_in_status:1
             };
             connection.query(sql,post,function(err,result){
             connection.query("SELECT * FROM device_info WHERE device_info.gcm_tokken=?",[req.body.gcmTokken],function(err,data){
                var obj = Object.assign({}, ...data)
                //    console.log(obj);
                  return res.json({
                    "message":"device data has been saved and registeration id is",
                    "regId":obj.reg_id,
                    "status":200
                    
                               })
             })
            })
            })
        },
       
        exports.tokenupdate=async(req,res)=>{
            var sql = 'UPDATE device_info SET gcm_tokken = ? WHERE device_info.reg_id=?';
            var value = [req.body.token, req.body.reg_id];
            connection.query(sql,value,function(err,result){
                return res.json({
                    msg:"get data",
                    data:result,
                    status:1,
                    error:0              
                  })
            })
        },
        
        exports.useridupdate=async(req,res)=>{
            var sql = 'UPDATE device_info SET user_id = ? WHERE device_info.reg_id=?';
            var value = [req.body.date, req.body.id];
            connection.query(sql,value,function(err,result){
                return res.json({
                    msg:"get data",
                    data:result,
                    status:1,
                    error:0              
                  })
            })
        },
      
        exports.contestDetails=async(req,res)=>{
            const contestId=req.query.contest_id;
            // console.log(contestId);
            connection.query("SELECT contest_id AS contestId ,poster_url AS posterUrl,name AS name,description AS description ,end_date AS endDate, result_description AS resultDescription,start_date AS startDate,video_url AS videoUrl FROM contest WHERE contest.contest_id=?",[contestId],function(err,result){

            var obj = Object.assign({}, ...result);
            const current=Date.now();
            if(current<obj.endDate){
            const data={ "contestId": obj.contestId,
            "posterUrl": obj.posterUrl,
            "name": obj.name,
            "description": obj.description,
            "endDate":obj.endDate.toUTCString().substr(4,12) ,
            "resultDescription": obj.resultDescription,
            "startDate": obj.startDate.toUTCString().substr(4,12),
            "videoUrl": obj.videoUrl,
            "status": 1,
            "runningStatus": 1
        }
        return res.json({
            "message":"Contest Details..",
            "status":"200",
            "contest":data,
            "winners":[]
        })
    }else{
        const data={ "contestId": obj.contestId,
            "posterUrl": obj.posterUrl,
            "name": obj.name,
            "description": obj.description,
            "endDate":obj.endDate.toUTCString().substr(4,12) ,
            "resultDescription": obj.resultDescription,
            "startDate": obj.startDate.toUTCString().substr(4,12),
            "videoUrl": obj.videoUrl,
            "status": 1,
            "runningStatus": 2
        }
                return res.json({
                    "message":"Contest Details..",
                    "status":"200",
                    "contest":data,
                    "winners":[]
                })
            }
            })
        } ,
        exports.contestvideo=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
            const contestid=req.query.contest_id;
            var limit = 10;
            var page = req.query.last_page_index;
            var skip = page * limit - page;
            
            // console.log(contestid)
            connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
                var obj = Object.assign({}, ...result);
                const id=obj.id;
                // console.log(id);
                connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 0 THEN false ELSE true END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.is_deleted=0 ORDER BY video.no_of_like DESC LIMIT ? OFFSET ?",[id,id,id,contestid,limit,skip],function(err,result){
                    // console.log(result)
                    const n=result.length;
                     for (var i = 0; i < n; i++) {
                         Object.keys(result[i]).forEach(function (field) {
                         if(result[i][field] == null){
                             result[i][field] = 0;
                            if(result[i].verified==1){
                                result[i].verified=true;
                            }else{
                                result[i].verified=false;
                            }
                         }
                       
                         })                   
                 };
                
               
        
                return res.json({
                    "status": "200",
                    "message": "Contest details..",
                    "lastPageIndex": Number(page),
                    "videoResponse": result,
       
                });
            })
    })
           
        
        },
      
       exports.weeklycontest=async(req,res)=>{
           connection.query("SELECT * FROM weekly_contest",function(err,result){
            return res.json({
                "status": "200",
                "message": "List of Contest..",
                "videoResponse": result
            });
           })
       },

       exports.trendingVideo=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
        const page=req.body.lastPageCount;
        const contestid=req.body.contestId;
        // console.log(contestid)
        var limit = 10;
        var skip = page * limit - page;
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
            var obj = Object.assign({}, ...result);
            const id=obj.id;
            // console.log(id);
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.is_deleted=0 ORDER BY video.no_of_like DESC LIMIT ? OFFSET ?",[id,id,id,limit,skip],function(err,result){
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.is_deleted=0 ORDER BY video.no_of_like DESC",[id,id,id],function(err,response){
               
               if(undefined === result && result.length|| undefined === response && response.length){
                return res.json({
                "status": "200",
                "message": "Videos List..",
                "lastPageIndex": page,
                "videoResponse": "",
                })
               }else{
                const count=response.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Videos List..",
                        "lastPageIndex": page,
                        "videoResponse": "",
                        })
                }else{
                const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                     }
                     if(result[i].verified==1){
                         result[i].verified=true;
                     }else{
                         result[i].verified=false;
                     }
                   
                     })   

             };
            
        
    
            return res.json({
                "status": "200",
                "message": "Videos List..",
                "lastPageIndex": page,
                "videoResponse": result,
                
            });
        }
    }
        })
    })
})
       },
       exports.weeklyContestvideo=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
        const page=req.body.lastPageCount;
        const contestid=req.body.contestId;
          // console.log(contestid)
          var limit = 10;
          var skip = page * limit - page;
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
            var obj = Object.assign({}, ...result);
            const id=obj.id;
            // console.log(id);
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? LEFT JOIN weekly_contest ON weekly_contest.weekly_contest_id=video.contest_id WHERE video.is_deleted=0 LIMIT ? OFFSET ?",[id,id,id,limit,skip],function(err,result){
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? LEFT JOIN weekly_contest ON weekly_contest.weekly_contest_id=video.contest_id WHERE video.is_deleted=0",[id,id,id],function(err,response){
              if(undefined !== result && result.length && undefined !== response && response.length){
               
                const count=response.length;
                var totalPages = Math.ceil(count / limit);
                if(page>totalPages){
                    return res.json({
                        "status": "200",
                        "message": "Videos List..",
                        "lastPageIndex": page,
                        "videoResponse": "",
                        })
                }else{
                    const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                     }
                     if(result[i].verified='1'){
                         result[i].verified=true;
                     }else{
                        result[i].verified=false;

                     }
                   
                     })                   
             };
            
            return res.json({
                "status": "200",
                "message": "Videos List..",
                "lastPageIndex": page,
                "videoResponse": result,
                
            });
        }
    }else{
        return res.json({
            "status": "200",
            "message": "Videos List..",
            "lastPageIndex": page,
            "videoResponse": "",
            }) 
    }
        })
        })
    })
       },
       exports.followinVideos=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
        const page=req.body.lastPageCount;
        const contestid=req.body.contestId;
        // console.log(headerval);
        var limit = 10;
        var skip = page * limit - page;
    
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,data){
            var obj = Object.assign({}, ...data);
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE relation.follower_id=? AND video.is_deleted=0 LIMIT ?  OFFSET ?",[obj.id,obj.id,obj.id,limit,skip],function(err,result){
                connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId,CASE WHEN user.is_user_verified = 1 THEN 1 ELSE '0' END AS verified FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE relation.follower_id=? AND video.is_deleted=0",[obj.id,obj.id,obj.id],function(err,response){
                  
            if('undefined' === result || 'undefined' === response){  
                return res.json({
                    "status": "200",
                    "message": "List of videos..",
                    "lastPageIndex": page,
                    "videoResponse": "",
                    
                });
            }else{
            const count=response.length;
            var totalPages = Math.ceil(count / limit);
            if(page>totalPages){
                return res.json({
                    "status": "200",
                    "message": "Videos List..",
                    "lastPageIndex": page,
                    "videoResponse": "",
                    })
            }else{
            const n=result.length;
              
            for (var i = 0; i < n; i++) {
                Object.keys(result[i]).forEach(function (field) {
                if(result[i][field] == null){
                    result[i][field] = 0;
                }if(result[i].verified==1){
                   result[i].verified=true;
               }else{
                  result[i].verified=false;
    
               }
              
                })                   
        };
            return res.json({
                "status": "200",
                "message": "Videos List..",
                "lastPageIndex": page,
                "videoResponse": result,
                })
        }
    }
            })
            })   
            
                })
            
    
       },

       exports.contestVideoCatgory=async(req,res)=>{
            const headerval=req.headers.authorization.split(' ')[1];
        const page=req.query.last_page_index;
        const contestid=req.query.category_id;
        var limit = 10;
        var skip = page * limit - page;
        
        // console.log(contestid)
        if(page>0==true){
            return res.json({
                "status": "200",
                "message": "List of videos..",
                "lastPageIndex": page,
                "response":[],
                
                
            });
        }else{
        connection.query("SELECT DISTINCT contest_id AS contestId, description AS description ,end_date AS endDate,name AS name, poster_url AS posterUrl,result_description AS resultDescripion,start_date AS startDate,video_url AS videoUrl FROM contest WHERE contest.contest_id=?",[contestid],function(err,response){
            var data = Object.assign({}, ...response);
            
            const current=Date.now();
            
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,result){
            var obj = Object.assign({}, ...result);
            const id=obj.id;
            // console.log(id);
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.is_deleted=0 LIMIT ? OFFSET ?",[id,id,id,contestid,limit,skip],function(err,result){
                const n=result.length;
                 for (var i = 0; i < n; i++) {
                     Object.keys(result[i]).forEach(function (field) {
                     if(result[i][field] == null){
                         result[i][field] = 0;
                         result[i].verified=false
                     }
                   
                     })                   
             };
             if(current<obj.endDate){
                const responseData={ "contestId": data.contestId,
                "posterUrl": data.posterUrl,
                "name": data.name,
                "description": data.description,
                "endDate":data.endDate.toUTCString().substr(4,12) ,
                "resultDescription": data.resultDescripion,
                "startDate": data.startDate.toUTCString().substr(4,12),
                "videoUrl": data.videoUrl,
                "status": 1,
                "runningStatus": 1
            }
    
            const category=[{"contestResponse":responseData,"videoResponse":result}]
             
    
            return res.json({
                "status": "200",
                "message": "List of videos..",
                "lastPageIndex":Number(page),
                "response":category,
                
                
            });
        }else{
            const responseData={ "contestId": data.contestId,
                "posterUrl": data.posterUrl,
                "name": data.name,
                "description": data.description,
                "endDate":data.endDate.toUTCString().substr(4,12) ,
                "resultDescription": data.resultDescripion,
                "startDate": data.startDate.toUTCString().substr(4,12),
                "videoUrl": data.videoUrl,
                "status": 1,
                "runningStatus": 2
            }
    
            const category=[{"contestResponse":responseData,"videoResponse":result}]
             
    
            return res.json({
                "status": "200",
                "message": "List of videos..",
                "lastPageIndex": Number(page),
                "response":category,
                
                
            });
        }
        })
    })
})
}   
    
    },

       exports.sample=async(req,res)=>{
    //    const value="4";
    //    const post="7"
        // connection.query("SELECT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? ",[23,23,23,1],function(err,result){
        //    const n=result.length;
        // //    console.log(n)
        //     for (var i = 0; i < n; i++) {
        //         Object.keys(result[i]).forEach(function (field) {
        //         if(result[i][field] == null){
        //             result[i][field] = 0;
        //         }
              
        //         })                   
        // };
        // console.log(result);
        connection.query("SELECT * FROM video WHERE video.user_id=?",[4],function(err,result){
            return res.json({
                msg:"get data",
                data:result              
              })
        })
    }
    exports.contestpoll=async(req,res)=>{
        const contestId=req.body.contestId;
        const headerval=req.headers.authorization.split(' ')[1];
        const page=req.body.lastPageIndex;
        var limit = 10;
        var skip = page * limit - page;
        
      
        connection.query("SELECT * FROM contest WHERE contest.contest_id=?",[contestId],function(err,result){
            var obj = Object.assign({}, ...result);
            var months = new Array(12);
                months[0] = "January";
                months[1] = "February";
                months[2] = "March";
                months[3] = "April";
                months[4] = "May";
                months[5] = "June";
                months[6] = "July";
                months[7] = "August";
                months[8] = "September";
                months[9] = "October";
                months[10] = "November";
                months[11] = "December";
            const startDate=obj.start_date;
            const yy=startDate.getFullYear();
            const mm=startDate.getUTCMonth()+1;
            const dd=startDate.getDate();
            const start=dd+"-"+mm+"-"+yy;
            const endDate=obj.end_date;
            // console.log(endDate)
            const yyy=endDate.getFullYear();
            const mmm=endDate.getMonth()+1;
            const ddd=endDate.getDate();
            const end=ddd+"-"+mmm+"-"+yyy;
            var now = new Date().getTime();
            // console.log(now)
            
            var timer =endDate - now ;
            var timeleft=timer+153013381;
            // console.log(timeleft)
            // console.log(-2*86400000)
            // console.log(endDate>now);
            var days = Math.floor(timeleft / (1000 * 60 * 60 * 24));
            var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
            const waitPeriodFormatted=days+":"+hours+":"+minutes+":"+seconds;
            const waitPeriod="PT-"+days+"d-"+hours+"h-"+minutes+"m-"+seconds+"s";
            // console.log(days,hours,minutes,seconds);
            var current = new Date();
            const time=current.toLocaleTimeString();
            const y=current.getFullYear();
            const m=current.getUTCMonth()+1;
            const d=current.getDate();
            const dateTime=y+"-"+m+"-"+d+"T"+time;
            // console.log(dateTime);
            const runningStatus="1";
            if(endDate>now ){
                connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,data){
                    var objdata = Object.assign({}, ...data);
                    const id=objdata.id;
            console.log(id)
                if(undefined===id){
             
            connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.is_deleted=0",[id,id,id,contestId],function(err,result){
                    const n=result.length
                     for (var i = 0; i < n; i++) {
                         Object.keys(result[i]).forEach(function (field) {
                         if(result[i][field] == null){
                             result[i][field] = 0;
                             result[i].totalScore=result[i].likeCount+result[i].watchCount;
                             result[i].startDate=start;
                             result[i].endDate=end;
                             result[i].verified=Boolean(false)
                         }
                       
                         })                   
                 };
                 const sorted=result.sort((a, b) => {
                    return b.totalScore - a.totalScore;
                });
                // console.log(sort);
                // Some array I got from async call
                const removeDuplicatesFromArrayByProperty = (arr, prop) => arr.reduce((accumulator, currentValue) => {
                    if(!accumulator.find(obj => obj[prop] === currentValue[prop])){
                      accumulator.push(currentValue);
                    }
                    return accumulator;
                  }, [])
              
                  const resultResponse=removeDuplicatesFromArrayByProperty(sorted, 'userId');
         
                  const m=resultResponse.length;
                  for (var i = 0; i < m; i++) {
                    Object.keys(resultResponse[i]).forEach(function (field) {
                    if(resultResponse[i][field] !== null){
                        resultResponse[i].rank=i+1;
                    }
                  
                    })                   
            };
            return res.json({
                "status": "200",
                "message": "Poll videos..",
                "lastPageIndex": Number(page),
                "myRank": 0,
                "runningStatus":Number(runningStatus),
                "waitPeriod": timeleft,
                "currentTime":dateTime,
                "waitPeriodFormatted": waitPeriodFormatted,
                "myVideoData":[],
                "videoResponse":resultResponse
            })
        })
    

}else{
    var objdata = Object.assign({}, ...data);
    const id=objdata.id;
    connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.is_deleted=0",[id,id,id,contestId],function(err,rank){
        const count=rank.length;
        for (var i = 0; i < count; i++) {
            Object.keys(rank[i]).forEach(function (field) {
            if(rank[i][field] == null){
                rank[i][field] = 0;
                rank[i].totalScore=rank[i].likeCount+rank[i].watchCount;
                rank[i].verified=Boolean(false);
                rank[i].endDate=end;
                rank[i].startDate=start
            }
          
            })                   
    };
   const sort=rank.sort((a, b) => {
            return b.totalScore - a.totalScore;
        });
        // console.log(sort);
        // Some array I got from async call
        const removeDuplicatesFromArrayByProperty = (arr, prop) => arr.reduce((accumulator, currentValue) => {
            if(!accumulator.find(obj => obj[prop] === currentValue[prop])){
              accumulator.push(currentValue);
            }
            return accumulator;
          }, [])
      
          const videoResponse=removeDuplicatesFromArrayByProperty(sort, 'userId');
 
          const m=videoResponse.length;
          for (var i = 0; i < m; i++) {
            Object.keys(videoResponse[i]).forEach(function (field) {
            if(videoResponse[i][field] !== null){
                videoResponse[i].rank=i+1;
            }
          
            })                   
    };
     const ranker = videoResponse.findIndex(x => x.userId ===id)+1;
        //   console.log("--------->"+uniqueAddresses);
       
   
 connection.query("SELECT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.user_id=?",[id,id,id,contestId,id],function(err,userVideo){
            const l=userVideo.length;  
            
    for (var i = 0; i < l; i++) {
        Object.keys(userVideo[i]).forEach(function (field) {
        if(userVideo[i][field] == null){
            userVideo[i][field] = 0;
            userVideo[i].totalScore=userVideo[i].likeCount+userVideo[i].watchCount;
            userVideo[i].verified=Boolean(false);
        }
      
        })                   
};
const mysort=userVideo.sort((a, b) => {
    return b.totalScore - a.totalScore;
});

if(mysort[0]===undefined){

return res.json({
   "status": "200",
   "message": "Poll videos..",
   "lastPageIndex": Number(page),
   "myRank":Number(ranker),
   "runningStatus":Number(runningStatus),
   "waitPeriod": timeleft,
   "currentTime":dateTime,
   "waitPeriodFormatted": waitPeriodFormatted,
   "myVideoData":[],
   "videoResponse":videoResponse
})
}else{
    return res.json({
        "status": "200",
        "message": "Poll videos..",
        "lastPageIndex": Number(page),
        "myRank":Number(ranker),
        "runningStatus":Number(runningStatus),
        "waitPeriod": timeleft,
        "currentTime":dateTime,
        "waitPeriodFormatted": waitPeriodFormatted,
        "myVideoData":[mysort[0]],
        "videoResponse":videoResponse
     })
}
})
 


})
}

                })
     }else if(timeleft>0){
    
     connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,pdata){
        var objtwodata = Object.assign({}, ...pdata);
        const pid=objtwodata.id;
        // console.log(pid);
        // console.log(contestId);
     connection.query("SELECT DISTINCT contests_poll.user_id AS userId,contests_poll.name AS name,contests_poll.profile_url AS profileUrl,contests_poll.total_score AS totalScore,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,contests_poll.video_id AS videoId,contests_poll.video_url AS videoUrl,contests_poll.video_watermark_url AS videoWatermarkUrl, contests_poll.track_title AS trackTitle,contests_poll.thumbnail_url AS thumbnailUrl,contests_poll.video_description AS videoDescription ,contests_poll.like_count AS likeCount,contests_poll.watch_count AS watchCount,contests_poll.comment_count AS commentCount,contests_poll.video_type AS videoType,contests_poll.audio_id AS audioId,contests_poll.prize AS prize FROM contests_poll LEFT JOIN relation ON relation.following_id=contests_poll.user_id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=contests_poll.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=contests_poll.video_id AND post_comment.user_id=? WHERE contests_poll.contest_id=?",[pid,pid,pid,contestId],function(err,contestdata){
    //   console.log(contestdata);
        if(contestdata!==undefined){
     connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,data){
        var objdata = Object.assign({}, ...data);
        const id=objdata.id;
        if(undefined===id){
             
        const m=contestdata.length;
        for (var i = 0; i < m; i++) {
          Object.keys(contestdata[i]).forEach(function (field) {
          if(contestdata[i][field] === null){
            contestdata[i][field] = 0;
            contestdata[i].isDeleted=Number(0);
            contestdata[i].verified=Boolean(false);
            contestdata[i].endDate=end;
            contestdata[i].startDate=start;
            contestdata[i].rank=i+1
          }
        
          })             
  };
//  console.log("aniket");
//  console.log(149901143 -130114524  ); 
//  console.log(172800000-19786619);
            return res.json({
                "status": "200",
                "message": "Poll videos..",
                "lastPageIndex": page,
                "myRank": 0,
                "runningStatus":Number(2),
                "waitPeriod": timeleft,
                "currentTime":dateTime,
                "waitPeriodFormatted": waitPeriodFormatted,
                "myVideoData":[],
                "videoResponse":contestdata
            })
        }else{
          
            // console.log(id);
     connection.query("SELECT DISTINCT contests_poll.user_id AS userId,contests_poll.name AS name,contests_poll.total_score AS totalScore,contests_poll.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,contests_poll.video_id AS videoId,contests_poll.video_url AS videoUrl,contests_poll.video_watermark_url AS videoWatermarkUrl, contests_poll.track_title AS trackTitle,contests_poll.thumbnail_url AS thumbnailUrl,contests_poll.video_description AS videoDescription ,contests_poll.like_count AS likeCount,contests_poll.prize AS prize,contests_poll.watch_count AS watchCount,contests_poll.comment_count AS commentCount,contests_poll.video_type AS videoType, contests_poll.audio_id AS audioId FROM contests_poll LEFT JOIN relation ON relation.following_id=contests_poll.user_id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=contests_poll.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=contests_poll.video_id AND post_comment.user_id=? WHERE contests_poll.contest_id=?",[id,id,id,contestId],function(err,contestsdata){
        const m=contestsdata.length;
        for (var i = 0; i < m; i++) {
          Object.keys(contestsdata[i]).forEach(function (field) {
          if(contestsdata[i][field] === null){
            contestsdata[i][field] = 0;
            contestsdata[i].isDeleted=Number(0);
            contestsdata[i].verified=Boolean(false);
            contestsdata[i].endDate=end;
            contestsdata[i].startDate=start;
            contestsdata[i].rank=i+1
          }
        
          })                   
  };
  const ranker = contestsdata.findIndex(x => x.userId ===id)+1;
  var result = contestsdata.find(obj => {
    return obj.userId === id;
  });
//   console.log(result);
  if(result===undefined){
  return res.json({
    "status": "200",
    "message": "Poll videos..",
    "lastPageIndex": Number(page),
    "myRank": Number(ranker),
    "runningStatus":Number(2),
    "waitPeriod": timeleft,
    "currentTime":dateTime,
    "waitPeriodFormatted": waitPeriodFormatted,
    "myVideoData":[],
    "videoResponse":contestsdata
})
  }else{
    return res.json({
        "status": "200",
        "message": "Poll videos..",
        "lastPageIndex": Number(page),
        "myRank": Number(ranker),
        "runningStatus":Number(2),
        "waitPeriod": timeleft,
        "currentTime":dateTime,
        "waitPeriodFormatted": waitPeriodFormatted,
        "myVideoData":[result],
        "videoResponse":contestsdata
    })
  }

     })
        }
    })
}else{
    // console.log("------->tryagain")
    connection.query("SELECT DISTINCT user.id AS userId,user.name AS name,user.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,video.video_id AS videoId,video.video_url AS videoUrl,video.video_watermark_url AS videoWatermarkUrl, video.track_title AS trackTitle,video.thumbnail_url AS thumbnailUrl,video.video_description AS videoDescription ,video.no_of_like AS likeCount,video.no_of_view AS watchCount,video.no_of_comment AS commentCount,video.is_deleted AS idDeleted,video.video_type AS videoType,video.audio_id AS audioId  FROM video LEFT JOIN user ON user.id=video.user_id LEFT JOIN relation ON relation.following_id=user.id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=video.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=video.video_id AND post_comment.user_id=? WHERE video.contest_id=? AND video.is_deleted=0",[pid,pid,pid,contestId],function(err,result){
            const n=result.length
             for (var i = 0; i < n; i++) {
                 Object.keys(result[i]).forEach(function (field) {
                 if(result[i][field] == null){
                     result[i][field] = 0;
                     result[i].totalScore=result[i].likeCount+result[i].watchCount;
                     result[i].startDate=start;
                     result[i].endDate=end;
                     result[i].verified=false
                 }
               
                 })                   
         };
         const sorted=result.sort((a, b) => {
            return b.totalScore - a.totalScore;
        });
        // console.log(sort);
        // Some array I got from async call
        const removeDuplicatesFromArrayByProperty = (arr, prop) => arr.reduce((accumulator, currentValue) => {
            if(!accumulator.find(obj => obj[prop] === currentValue[prop])){
              accumulator.push(currentValue);
            }
            return accumulator;
          }, [])
      
          const resultResponse=removeDuplicatesFromArrayByProperty(sorted, 'userId');
 
          const m=resultResponse.length;
          for (var i = 0; i < m; i++) {
            Object.keys(resultResponse[i]).forEach(function (field) {
            if(resultResponse[i][field] !== null){
                resultResponse[i].rank=i+1;
                resultResponse[i].contest_id=Number(contestId)
            }
          
            })                   
    };
    let sql = "insert into contests_poll (video_id,profile_url,name,comment_count,like_count,watch_count,thumbnail_url,track_title,video_description,video_type,video_url,video_watermark_url,contest_id,user_id,audio_id,total_score,ranks) values?";

    let values = [];
    
    
    for (let i = 0; i < resultResponse.length; i++) {
      values.push([resultResponse[i].videoId, resultResponse[i].profileUrl, resultResponse[i].name, resultResponse[i].commentCount, resultResponse[i].likeCount, resultResponse[i].watchCount,resultResponse[i].thumbnailUrl,resultResponse[i].trackTitle,resultResponse[i].videoDescription,resultResponse[i].videoType,resultResponse[i].videoUrl,resultResponse[i].videoWatermarkUrl,resultResponse[i].contest_id,resultResponse[i].userId,resultResponse[i].audioId,resultResponse[i].totalScore,resultResponse[i].rank])
    }

    
    connection.query(sql, [values], (err, result) => {
     
      console.log("rows affected " + result.affectedRows);
  
    return res.json({
        "status": "200",
        "message": "Poll videos..",
        "lastPageIndex":Number(page),
        "myRank": 0,
        "runningStatus":Number(runningStatus),
        "waitPeriod": timeleft,
        "currentTime":dateTime,
        "waitPeriodFormatted": waitPeriodFormatted,
        "myVideoData":[],
        "videoResponse":resultResponse
    })
})
});
         }
    

})
     })
     }else if(timeleft< 0 ){
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,data){
            var objdata = Object.assign({}, ...data);
            const id=objdata.id;
            // console.log(id);
            if(undefined===id){
        connection.query("SELECT DISTINCT contests_poll.user_id AS userId,contests_poll.name AS name,contests_poll.prize AS prize,contests_poll.total_score AS totalScore,contests_poll.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,contests_poll.video_id AS videoId,contests_poll.video_url AS videoUrl,contests_poll.video_watermark_url AS videoWatermarkUrl, contests_poll.track_title AS trackTitle,contests_poll.thumbnail_url AS thumbnailUrl,contests_poll.video_description AS videoDescription ,contests_poll.like_count AS likeCount,contests_poll.watch_count AS watchCount,contests_poll.comment_count AS commentCount,contests_poll.video_type AS videoType, contests_poll.audio_id AS audioId FROM contests_poll LEFT JOIN relation ON relation.following_id=contests_poll.user_id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=contests_poll.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=contests_poll.video_id AND post_comment.user_id=? WHERE contests_poll.contest_id=?",[id,id,id,contestId],function(err,contestdata){
                 
            const m=contestdata.length;
            for (var i = 0; i < m; i++) {
              Object.keys(contestdata[i]).forEach(function (field) {
              if(contestdata[i][field] === null){
                contestdata[i][field] = 0;
                contestdata[i].isDeleted=Number(0);
                contestdata[i].verified=Boolean(false);
                contestdata[i].endDate=end;
                contestdata[i].startDate=start;
                contestdata[i].rank=i+1
              }
            
              })                   
      };
     
                return res.json({
                    "status": "200",
                    "message": "Poll videos..",
                    "lastPageIndex":Number(page),
                    "myRank": 0,
                    "runningStatus":Number(3),
                    "waitPeriod": timeleft,
                    "currentTime":dateTime,
                    "waitPeriodFormatted": waitPeriodFormatted,
                    "myVideoData":[],
                    "videoResponse":contestdata
                })
            })
            }else{
              
                // console.log(id);
            connection.query("SELECT DISTINCT contests_poll.user_id AS userId,contests_poll.name AS name,contests_poll.total_score AS totalScore,contests_poll.prize AS prize,contests_poll.profile_url AS profileUrl,CASE WHEN post_like.like_type  = 0 THEN 1 END AS likeStatus ,CASE WHEN post_comment.comment_type = 0 THEN 1 END  AS commentStatus,CASE WHEN relation.following_and_follower_relation_id IS NULL THEN NULL ELSE 1 END  AS followStatus,contests_poll.video_id AS videoId,contests_poll.video_url AS videoUrl,contests_poll.video_watermark_url AS videoWatermarkUrl, contests_poll.track_title AS trackTitle,contests_poll.thumbnail_url AS thumbnailUrl,contests_poll.video_description AS videoDescription ,contests_poll.like_count AS likeCount,contests_poll.watch_count AS watchCount,contests_poll.comment_count AS commentCount,contests_poll.video_type AS videoType, contests_poll.audio_id AS audioId FROM contests_poll LEFT JOIN relation ON relation.following_id=contests_poll.user_id AND relation.follower_id=? LEFT JOIN post_like ON post_like.reference_id=contests_poll.video_id AND post_like.user_id=? LEFT JOIN post_comment ON post_comment.reference_id=contests_poll.video_id AND post_comment.user_id=? WHERE contests_poll.contest_id=?",[id,id,id,contestId],function(err,contestsdata){
            const m=contestsdata.length;
            for (var i = 0; i < m; i++) {
              Object.keys(contestsdata[i]).forEach(function (field) {
              if(contestsdata[i][field] === null){
                contestsdata[i][field] = 0;
                contestsdata[i].isDeleted=Number(0);
                contestsdata[i].verified=Boolean(false);
                contestsdata[i].endDate=end;
                contestsdata[i].startDate=start;
                contestsdata[i].rank=i+1
              }
            
              })                   
      };
      const ranker = contestsdata.findIndex(x => x.userId ===id)+1;
      var result = contestsdata.find(obj => {
        return obj.userId === id;
      });
      if(result===undefined){
      return res.json({
        "status": "200",
        "message": "Poll videos..",
        "lastPageIndex": Number(page),
        "myRank": Number(ranker),
        "runningStatus":Number(3),
        "waitPeriod": timeleft,
        "currentTime":dateTime,
        "waitPeriodFormatted": waitPeriodFormatted,
        "myVideoData":[],
        "videoResponse":contestsdata
    })
}else{
    return res.json({
        "status": "200",
        "message": "Poll videos..",
        "lastPageIndex": Number(page),
        "myRank": Number(ranker),
        "runningStatus":Number(3),
        "waitPeriod": timeleft,
        "currentTime":dateTime,
        "waitPeriodFormatted": waitPeriodFormatted,
        "myVideoData":[result],
        "videoResponse":contestsdata
    })
}
})
}
            })
        }
         
     
    
    })

}      

    exports.deleteVideo=async(req,res)=>{
        const videoId=req.body.videoId;
        const isDeleted=req.body.isDeleted;
        var current = new Date();
        
        const time=current.toLocaleTimeString();
            const y=current.getFullYear();
            const m=current.getUTCMonth()+1;
            const d=current.getDate();
            const dateTime=y+"-"+m+"-"+d+"T"+time;
        connection.query("UPDATE video SET deleted_on=?,is_deleted=? WHERE video.video_id=?",[dateTime,isDeleted,videoId],function(err,result){
             if(err)
             {throw err;
            //     return res.json({
            //     "status": "500",
            //     "message": "video can not deleted.."
            //     })
            }else{
                return res.json({
                "status": "200",
                "message": "Video removed successfully."
                })
            }
        })
    }
    exports.homepage=async(req,res)=>{
        var limit = 10;
        var page = 1;
        var skip = page * limit - page;
            const headerval=req.headers.authorization.split(' ')[1];
       connection.query("SELECT DISTINCT user.name AS name ,video.video_id AS videoId,video.video_id AS videoId, video.thumbnail_url AS thumbnailUrl, video.video_url AS videoUrl,video.video_description AS description,video.video_watermark_url AS videoWatermarkUrl,user.id AS userId,user.username AS username FROM video INNER JOIN user ON user.id=video.user_id LIMIT ? OFFSET ?",[limit,skip],function(err,result){
        
        if(undefined !== result && result.length){
            for (var i = 0; i < result.length; i++) {
                Object.keys(result[i]).forEach(function (field) {
                if(result[i][field] !== null){
                    result[i].videoId= result[i].videoId.toString();
                    result[i].userId=result[i].userId.toString();
                }
              
                })                   
        };
        }else{
         const result=[]
}
        connection.query("SELECT DISTINCT user.name ,video.video_id,video.video_id, video.thumbnail_url, video.video_url,video.video_watermark_url,user.id AS user_id,user.username FROM video INNER JOIN user ON user.id=video.user_id ORDER BY video.no_of_like DESC LIMIT ? OFFSET ?",[limit,skip],function(err,video){
            
            if(undefined !== video && video.length){
                for (var i = 0; i < video.length; i++) {
                    Object.keys(video[i]).forEach(function (field) {
                    if(video[i][field] !== null){
                        video[i].video_id= video[i].video_id.toString();
                        video[i].user_id=video[i].user_id.toString();
                    }
                  
                    })                   
            };
            }else{
             const video=[];
            }
        connection.query("SELECT weekly_contest_id AS weeklyContestId,category_name AS categoryName,thumbnail_url AS thumbnailUrl FROM weekly_contest",[],function(err,response){
       connection.query("SELECT weekly_challenge_id AS weeklyChallengeId,video_url AS videoUrl FROM weekly_challenge",[],function(err,data){
        connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,user){ 
            var obj = Object.assign({}, ...user);
          
         connection.query("SELECT * FROM relation WHERE relation.following_id=?",[obj.id],function(err,follower){  
          
            var objtwo = Object.assign({}, ...follower);
            
           if(objtwo.following_id>0==true){
        return res.json({
            "status": "200",
            "message": "Success",
            "trendingResponse":result,
            "videoResponse":video,
            "weeklyChallengeResponse":data,
            "weeklyContestResponse":response,
            "lastPageIndex":page,
            "following":true
            
           })
        }else{
            return res.json({
                "status": "200",
                "message": "Success",
                "trendingResponse":result,//
                "videoResponse":video,//
                "weeklyChallengeResponse":data,
                "weeklyContestResponse":response,
                "lastPageIndex":page,
                "following":false
            })
        }
       }) 
    })
})
       })
    
    }) 
    })
    }
      exports.sampltwo=async(req,res)=>{
//   delete Persons 
        connection.query("DESC bamchikDev.video", function (err, result) {
if(err) throw err;
            return res.json({
                "status": "200",
                "message": "Successfully login..",
                "data":result
            })
        })
      }
    // "CREATE TABLE contests_poll (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, video_id INT, profile_url VARCHAR(255),name VARCHAR(255),comment_count INT,like_count INT,watch_count INT,thumbnail_url VARCHAR(255),track_title VARCHAR(225),video_description VARCHAR(225),video_type INT,video_url VARCHAR(255),video_watermark_url VARCHAR(255),contest_id BIGINT,user_id BIGINT,audio_id INT,total_score INT,ranks INT)  
// following's user detail is not comming
// 
exports.uploadPic=async(req,res)=>{
    const headerval=req.headers.authorization.split(' ')[1];
    const type=req.body.image_type;
    connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,user){
        var objtwo = Object.assign({}, ...user);

    if(type==='cover'){
        const coverUrl=req.file.location;
        connection.query("UPDATE user SET cover_url =? WHERE user.id=?", [coverUrl, objtwo.id], function(err,cover){

return res.json({
    "status":"200",
    "message":"cover picture uploaded",
    
})
})

}else{
    const profleUrl=req.file.location;
    connection.query("UPDATE user SET profile_url =? WHERE user.id=?", [profleUrl, objtwo.id], function(err,profile){ 
        return res.json({
            "status":"200",
            "message":"profile picture uploaded",
        
        })
    })
}
})
}
