

exports.getDashbaord = async(req, res)=>{
    return res.render('dashboard');
 
}
