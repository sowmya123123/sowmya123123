

// *********REGISTER FUNCTION ********** //
exports.getRegister = (req, res) => {
   res.render('register')
}
exports.errors = (req, res) => {
   res.render('error');
}

exports.create = async (req, res) => {
   const data = await adminModel.findOne({ "email": req.body.email });
   //console.log(data);
   if (!data) {

      const token = jwt.sign(req.body, 'secret_key');
      const formvalue = new adminModel({
         ...req.body,
         status: 1,
         token
      });

      //console.log(formvalue);
      const finaldata = await formvalue.save();
      const form = new addressModel({
         ...req.body,
         profile_id: finaldata._id,
      })
      const save = await form.save();
      return res.redirect('/admin/getagent');

   } else {
      return res.status(200).json({
         msg: 'This user is already exist...',
         data: 'Data not found',
         status: 0,
         error: 1
      });
   }
}


//*********LOGIN FUNCTION*********//

exports.getLogin = async (req, res) => {
   const data={}
   res.render('login',{data});
}
exports.login = async (req, res) => {
   const param = req.body;
   const query = { "email": param.email, "password": param.password };
   //console.log(query, param)
   try {  
      
         const data = await adminModel.findOne(query);
         const token = data.token;
         //console.log(token)
         res.cookie('jwt', token, { httpOnly: true }),
            res.redirect('/admin/dashboard');
     
   } catch (err) {
      const data={'error':'Invalid! Email Or Password'};
      res.render('login',{data});
   }
}
exports.logout = async (req, res) => {
   const token = '';
   res.cookie('jwt', token, { maxAge: 1 });
   res.redirect('/admin/login');
}



