var createError = require('http-errors');
var express = require('express');
require('dotenv').config();

var path = require('path');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
	res.header('Access-Control-Allow-Origine','*');
	res.header('Access-Control-Allow-Headers','*');

	if(req.method === 'OPTIONS'){
		res.header('Access-Control-Allow-Methods','PUT, PATCH, POST, GET, DELETE');
	}
	next();
});

app.get('/', function(req,res){
        
        res.send('test route');
    
});

const adminRoute = require('./routes/admin');
app.use('/admin', adminRoute);

const apiRoute=require('./routes/apiroutes');
app.use('/api',apiRoute);

app.use('/', indexRouter);
app.use('/users', usersRouter);


// error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
      res.status(err.status || 500);
      res.send('Server Error');
  });
}


app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.send('Internal server Error');
  
});
const port = process.env.PORT || 8081;
app.listen(port, () => console.log(`Server is running on ${port}, http://localhost:${port}`));

module.exports = app;
