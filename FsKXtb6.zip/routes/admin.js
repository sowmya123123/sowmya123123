const express=require('express');
const Route = express.Router();
const dashboardController=require('../controllers/dashboard');
const adminController=require('../controllers/admin');
//var token = [tokencheck];

/* login */
Route.post('/login',adminController.login);
Route.get('/login',adminController.getLogin);
Route.get('/error',adminController.errors);

/* register */
Route.post('/register',adminController.create);
Route.get('/register',adminController.getRegister);

/* dashboard */
Route.get('/dashboard', dashboardController.getDashbaord);

Route.get('/logout',adminController.logout);


module.exports = Route;
