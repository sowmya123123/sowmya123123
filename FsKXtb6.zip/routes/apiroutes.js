const express=require('express');
const Route = express.Router();
const connection=require('../config/db');
var dateTime = require('node-datetime');
var dt = dateTime.create();
const apiController=require('../controllers/api');
const upload=require('../middleware/picUploadMiddilware');
const uploadImageToS3=require('../middleware/videocover');

const tokencheck = require('../middleware/apitoken');
const uploadMulter = multer({ dest: 'public/'});
const uploadFile = require('../middleware/videocover')
const path = require('path');

//const agenttoken=require('../middleware/agenttoken');
var token = [tokencheck];

Route.post('/users/signin',apiController.login);
Route.post('/signup',apiController.signUp);
Route.post('/users/check',apiController.checkusername);
Route.post('/users/refer',apiController.verifyReferCode);
Route.get('/audioCategory',apiController.getaudiocategory);
Route.get('/getcategoryDetails',apiController.getCategorydetails);
Route.get('/searchcategory',apiController.searchCategory);
Route.post('/audio/list',apiController.getAllaudioromcategory);
Route.get('/getallsongs',apiController.getAllAudio);
Route.post('/audio/search',apiController.findAudio);
Route.post('/audio/detail',apiController.getAudiodetails);
Route.post('/audio/videolist',apiController.getVideolistforAudio);
Route.post('/users/meVideo',token,apiController.myVideo);
Route.post('/users/publicVideo',apiController.publicvideo);
Route.post('/audio/save',token,apiController.saveaudio);
Route.post('/audio/savedAudio',token,apiController.getsavedaudio);
Route.post('/get-CommentDetails',apiController.getCommentDetails);
Route.post('/comment',token,apiController.postcomment);
Route.delete('/deleteComment',token,apiController.deleteComment);
Route.put('/update-comment',token,apiController.updateComment);
Route.post('/users/comment',apiController.getAllComment);
Route.post('/users/publicDetail',apiController.getuserDetails);
Route.post('/users/meDetail',token,apiController.getmineDetails);
Route.post('/users/follower',apiController.getfollower);
Route.post('/users/following',apiController.getfollowing);
Route.get('/getvideolist',token,apiController.getvideolist);
Route.post('/videos/video',apiController.getparticularvideo);//video/video get perticular vidoe
Route.post('/reportvideo',token,apiController.reportVideo);
Route.post('/search',apiController.searchuser);
Route.put('/follow',token,apiController.doFollow);//0unfollow 1follow
Route.put('/like',token,apiController.likeVideo);//1like liked
Route.post('/devicedata/deviceinfo',token,apiController.devicedata);
Route.post('/updatetoken-dviceinfo',token,apiController.tokenupdate);
Route.post('/updateuserid-dviceinfo',token,apiController.useridupdate);
Route.get('/contests/detail',apiController.contestDetails);
Route.get('/contests/video',apiController.contestvideo);
Route.get('/weekly/contest',apiController.weeklycontest);
Route.post('/videos/trending',apiController.trendingVideo);
Route.post('/videos/weekly',apiController.weeklyContestvideo);
Route.post('/videos/following',apiController.followinVideos);
Route.get('/contests',apiController.contestVideoCatgory);
Route.post('/contests/poll',apiController.contestpoll);
Route.put('/videos/delete',token,apiController.deleteVideo);
Route.post('/videos/homeNew',apiController.homepage);

Route.put('/profile',token,upload.upload.single('img'),apiController.uploadPic);

Route.post('/sampletwo-check',apiController.sampltwo);
Route.get('/sample-check',apiController.sample);

const cpUpload =  uploadMulter.fields([{ name:'video_file', maxCount:1},{ name:'video_file_watermark', maxCount:1 },{ name:'audio_file', maxCount:1 },{ name:'cover_file', maxCount:1 }]);

var uploadFilePromisses = []

Route.post('/video/newupload', cpUpload, async function(req, res, next){
 
  var videoFile = req.files.video_file;
  var videoFileWatermark = req.files.video_file_watermark;
  var audioFile=req.files.audio_file;
  var coverFile=req.files.cover_file;
  var videoFileWatermarkKey ='BamchikDev/VideoWatermark/'+Date.now().toString() ;

  uploadFilePromisses.push(uploadFile(videoFileWatermark[0], videoFileWatermarkKey))
  var videoFileKey = 'BamchikDev/Video/'+Date.now().toString()
  uploadFilePromisses.push(uploadFile(videoFile[0], videoFileKey))
  var audioFileKey='BamchikDev/Audio/'+Date.now().toString()
  uploadFilePromisses.push(uploadFile(audioFile[0], audioFileKey))
  var coverFileKey='BamchikDev/Cover/'+Date.now().toString()
  uploadFilePromisses.push(uploadFile(coverFile[0], coverFileKey))

  Promise.all(uploadFilePromisses)
    .then(async(values) => {
      const contestId=req.body.contest_id;
      const videoType=req.body.video_type;
      const videoTitle=req.body.video_title;
      const videoDescription=req.body. video_description;
      const isAuthorized=req.body.is_Authorized;
      const audioId=req.body.audio_id;
      const dateTime= dt.format('Y-m-d H:M:S').slice(0,19).replace('T',':')
      const videourl=values.find(element => element.includes("/Video/"));
      const videowatermark=values.find(element => element.includes("/VideoWatermark/"));
      const audiourl=values.find(element => element.includes("/Audio/"));
      const coverurl=values.find(element => element.includes("/Cover/"));

      const headerval=req.headers.authorization.split(' ')[1];
      connection.query("SELECT * FROM user WHERE user.token=?",[headerval],function(err,user){
        var objtwo = Object.assign({}, ...user);
        let sql = 'INSERT INTO video SET ?';
        let post = {
            cover_url: coverurl,
            created_on: dateTime,
            name: objtwo.name,
            username:objtwo.username,
            no_of_comment:0,
            no_of_like:0,
            no_of_view:0,
            thumbnail_url:"",
            track_title:"",
            username:objtwo.username,
            video_category:"",
            video_description:videoDescription,
            video_title:videoTitle,
            video_type:videoType,
            video_url:videourl,
            video_watermark_url:videowatermark,
            contest_id:contestId,
            user_id:objtwo.id,
            audio_id:audioId,
            deleted_by:"",
            deleted_on:"",
            total_score:""             
        };
        // console.log(post);
        connection.query(sql, post, function (err, result) {
          if(err) throw err;
          return res.json({
            "status":"200",
            "message":"video uploaded Successfully",
            
        })
        })
      
       })
    }, reason => {
      console.log(reason)
    })


}
)

module.exports = Route;